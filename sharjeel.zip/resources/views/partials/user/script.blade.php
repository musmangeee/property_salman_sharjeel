 <!--Jquery--> 
<script src="{{ URL::asset('property/js/jquery-3.2.1.js') }}"></script> 

<!--Popper--> 
<script src="{{ URL::asset('property/js/popper.min.js') }}"></script> 

<!--Bootstrap--> 
<script src="{{ URL::asset('property/js/bootstrap.min.js') }}"></script> 
<script src="{{ URL::asset('property/js/owl.carousel.js') }}"></script> 
<script src="{{ URL::asset('property/js/counter.js') }}"></script> 

<!--Custom JS--> 
<script src="{{ URL::asset('property/js/custom.js') }}"></script>
<!-- Parsley js -->
<script src="{{ URL::asset('js/parsley.min.js') }}"></script>

@yield('jsscript')